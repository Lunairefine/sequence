import { runBrowserTests } from './utils/browser-test-runner'

runBrowserTests('mux-transport', 'mux-transport/mux.test.html')
