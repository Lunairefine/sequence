import { runBrowserTests } from './utils/browser-test-runner'

runBrowserTests('proxy-transport-channel', 'proxy-transport/channel.test.html')
