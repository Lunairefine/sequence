import { runBrowserTests } from './utils/browser-test-runner'

runBrowserTests('json-rpc-provider', 'json-rpc-provider/rpc.test.html')
