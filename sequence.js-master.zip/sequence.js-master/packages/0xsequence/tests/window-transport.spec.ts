import { runBrowserTests } from './utils/browser-test-runner'

runBrowserTests('window-transport', 'window-transport/dapp.test.html')
