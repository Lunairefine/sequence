export * from '@0xsequence/config'

export type {
  WalletConfig,
  WalletState
} from '@0xsequence/config'
