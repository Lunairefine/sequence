
export enum JsonRpcMethod {
  ethCall = "eth_call",
  ethGetBalance = "eth_getBalance",
  ethGetCode = "eth_getCode",
}
